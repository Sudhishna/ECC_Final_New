draw2d.shape.node.generic = draw2d.shape.node.wistarStandalone.extend({
    NAME: "draw2d.shape.node.generic",
    MANAGEMENT_INTERFACE_PREFIX: "eth",
    MANAGEMENT_INTERFACE_INDEX: -1,
    DOMAIN_CONFIGURATION_FILE: "domain.xml",
    ICON_WIDTH: 50,
    ICON_HEIGHT: 50,
    ICON_FILE: "/static/images/router.png",
});
