draw2d.shape.node.vmx = draw2d.shape.node.wistarStandalone.extend({
    NAME: "draw2d.shape.node.vmx",
    INTERFACE_PREFIX: "ge-0/0/",
    MANAGEMENT_INTERFACE_PREFIX: "em",
    MANAGEMENT_INTERFACE_INDEX: 0,
    DOMAIN_CONFIGURATION_FILE: "domain.xml",
    DUMMY_INTERFACE_LIST: ["1"],
    ICON_WIDTH: 50,
    ICON_HEIGHT: 50,
    ICON_FILE: "/static/images/vmx.png",
});
