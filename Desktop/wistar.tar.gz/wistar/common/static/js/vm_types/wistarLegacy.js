draw2d.shape.node.vmxIcon = draw2d.shape.node.vmx.extend({
    // ONLY HERE FOR COMPATIBILITY! DO NOT USE THIS FURTHER BEYOND 03-2016
    NAME: "draw2d.shape.node.vmxIcon",
});
draw2d.shape.node.vsrxIcon = draw2d.shape.node.vsrx.extend({
    NAME: "draw2d.shape.node.vsrxIcon",
});
draw2d.shape.node.externalCloudIcon = draw2d.shape.node.externalCloud.extend({
    NAME: "draw2d.shape.node.externalCloudIcon",
});
draw2d.shape.node.internalCloudIcon = draw2d.shape.node.internalCloud.extend({
    NAME: "draw2d.shape.node.internalCloudIcon",
});
draw2d.shape.node.linuxIcon = draw2d.shape.node.linux.extend({
    NAME: "draw2d.shape.node.linuxIcon",
});
draw2d.shape.node.genericIcon = draw2d.shape.node.generic.extend({
    NAME: "draw2d.shape.node.genericIcon",
});