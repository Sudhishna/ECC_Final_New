draw2d.shape.node.space = draw2d.shape.node.linux.extend({
    NAME: "draw2d.shape.node.space",
    CLOUD_INIT_SUPPORT: false,
    MANAGEMENT_INTERFACE_PREFIX: "eth",
    MANAGEMENT_INTERFACE_INDEX: -1,
    INTERFACE_OFFSET: 0,
    VCPU: 4,
    VRAM: 16384,
    ICON_WIDTH: 50,
    ICON_HEIGHT: 50,
    ICON_FILE: "/static/images/space.png",
});
