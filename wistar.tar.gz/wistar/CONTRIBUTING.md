To contribute:

 - fork the project
 - make your changes
 - send a merge request

pretty simple!

Send questions to our Slack channel at:

https://wistar-vtm.slack.com/