draw2d.shape.node.ubuntu16 = draw2d.shape.node.linux.extend({
    NAME: "draw2d.shape.node.ubuntu16",
    INTERFACE_PREFIX: "ens",
    // useful for interface naming in the GUI and via automation actions
    INTERFACE_OFFSET: 4,
    MANAGEMENT_INTERFACE_PREFIX: "ens",
    RESIZE_SUPPORT: true
});
