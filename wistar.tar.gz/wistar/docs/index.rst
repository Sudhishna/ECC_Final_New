.. Wistar documentation master file, created by
   sphinx-quickstart on Tue Dec 20 15:09:49 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Wistar's documentation!
==================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   about
   getting_started
   tips_and_tricks
   contributing

.. image:: screenshots/screenshot.png

This documentation is a work in progress. Feel free to offer suggestions!


